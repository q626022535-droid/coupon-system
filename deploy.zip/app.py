"""
券码领取系统 - 后端 + 前端 (Streamlit)
"""
import streamlit as st
import sqlite3
import hashlib
import os
from datetime import datetime
import io
import secrets

# 数据库初始化 - 使用绝对路径确保持久化
DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(DB_DIR, "coupon_system.db")

def init_db():
    """初始化数据库"""
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    
    # 用户表
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        department TEXT,
        name TEXT,
        session_token TEXT
    )''')
    
    # 券码表
    c.execute('''CREATE TABLE IF NOT EXISTS coupons (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        amount REAL NOT NULL,
        status TEXT DEFAULT 'pending',
        issued_to TEXT,
        department TEXT,
        apply_time TEXT,
        issue_time TEXT
    )''')
    
    # 创建默认管理员 (admin/admin123)
    try:
        c.execute("INSERT INTO users (username, password, role, name) VALUES (?, ?, ?, ?)",
                  ("admin", hashlib.sha256("admin123".encode()).hexdigest(), "super_admin", "管理员"))
    except:
        pass
    
    conn.commit()
    conn.close()

def get_db():
    return sqlite3.connect(DB_FILE)

# 认证函数
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def verify_login(username, password):
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, role, name, department FROM users WHERE username=? AND password=?", 
              (username, hash_password(password)))
    user = c.fetchone()
    conn.close()
    return user

def verify_login_by_token(token):
    """通过token验证用户"""
    if not token:
        return None
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, role, name, department, username FROM users WHERE session_token=?", (token,))
    user = c.fetchone()
    conn.close()
    return user

def generate_session_token(user_id):
    """生成并保存session token"""
    token = secrets.token_hex(32)
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET session_token=? WHERE id=?", (token, user_id))
    conn.commit()
    conn.close()
    return token

def clear_session_token(user_id):
    """清除session token"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET session_token=NULL WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

def add_user(username, password, role, name, department=""):
    conn = get_db()
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password, role, name, department) VALUES (?, ?, ?, ?, ?)",
                  (username, hash_password(password), role, name, department))
        conn.commit()
        result = True
    except:
        result = False
    conn.close()
    return result

def get_all_users():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, username, role, name, department FROM users ORDER BY id")
    users = c.fetchall()
    conn.close()
    return users

def delete_user(user_id):
    """删除用户"""
    conn = get_db()
    c = conn.cursor()
    # 不允许删除超级管理员
    c.execute("SELECT role FROM users WHERE id=?", (user_id,))
    user = c.fetchone()
    if user and user[0] == "super_admin":
        conn.close()
        return False, "不能删除超级管理员"
    c.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()
    return True, "删除成功"

def update_user_role(user_id, new_role):
    """修改用户角色"""
    conn = get_db()
    c = conn.cursor()
    # 不允许修改超级管理员角色
    c.execute("SELECT role FROM users WHERE id=?", (user_id,))
    user = c.fetchone()
    if user and user[0] == "super_admin":
        conn.close()
        return False, "不能修改超级管理员角色"
    c.execute("UPDATE users SET role=? WHERE id=?", (new_role, user_id))
    conn.commit()
    conn.close()
    return True, "角色修改成功"

def update_user_password(user_id, new_password):
    """修改用户密码"""
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE users SET password=? WHERE id=?", (hash_password(new_password), user_id))
    conn.commit()
    conn.close()
    return True

# 券码管理函数
def upload_coupons(codes, amount):
    conn = get_db()
    c = conn.cursor()
    added = 0
    for code in codes:
        code = code.strip()
        if code:
            try:
                c.execute("INSERT INTO coupons (code, amount) VALUES (?, ?)", (code, amount))
                added += 1
            except:
                pass
    conn.commit()
    conn.close()
    return added

def get_coupons(status=None):
    conn = get_db()
    c = conn.cursor()
    if status:
        c.execute("SELECT id, code, amount, status, issued_to, department, apply_time, issue_time FROM coupons WHERE status=? ORDER BY id DESC", (status,))
    else:
        c.execute("SELECT id, code, amount, status, issued_to, department, apply_time, issue_time FROM coupons ORDER BY id DESC")
    coupons = c.fetchall()
    conn.close()
    return coupons

def get_available_coupons():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, code, amount FROM coupons WHERE status='pending' ORDER BY amount DESC")
    coupons = c.fetchall()
    conn.close()
    return coupons

def apply_coupon(coupon_id, name, department):
    conn = get_db()
    c = conn.cursor()
    c.execute("UPDATE coupons SET status='applying', issued_to=?, department=?, apply_time=? WHERE id=? AND status='pending'",
              (name, department, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), coupon_id))
    conn.commit()
    conn.close()

def approve_coupon(coupon_id, action):
    conn = get_db()
    c = conn.cursor()
    if action == "approve":
        c.execute("UPDATE coupons SET status='issued', issue_time=? WHERE id=?",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), coupon_id))
    else:
        c.execute("UPDATE coupons SET status='pending', issued_to=NULL, department=NULL, apply_time=NULL, issue_time=NULL WHERE id=?",
                  (coupon_id,))
    conn.commit()
    conn.close()

def delete_coupon(coupon_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("DELETE FROM coupons WHERE id=?", (coupon_id,))
    conn.commit()
    conn.close()

def delete_coupons_by_ids(coupon_ids):
    """批量删除券码"""
    conn = get_db()
    c = conn.cursor()
    placeholders = ",".join("?" * len(coupon_ids))
    c.execute(f"DELETE FROM coupons WHERE id IN ({placeholders})", coupon_ids)
    deleted = c.rowcount
    conn.commit()
    conn.close()
    return deleted

def delete_coupons_by_codes(codes):
    """根据券码批量删除"""
    conn = get_db()
    c = conn.cursor()
    deleted = 0
    for code in codes:
        code = code.strip()
        if code:
            c.execute("DELETE FROM coupons WHERE code=?", (code,))
            if c.rowcount > 0:
                deleted += 1
    conn.commit()
    conn.close()
    return deleted

def get_statistics():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT status, COUNT(*) FROM coupons GROUP BY status")
    stats = dict(c.fetchall())
    conn.close()
    return stats

# ====== 页面函数 ======

def page_login():
    st.set_page_config(page_title="券码领取系统", page_icon="🎫")
    
    st.markdown("""
    <style>
    .login-container {
        max-width: 400px;
        margin: 50px auto;
        padding: 30px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .stTitle { text-align: center; color: #1f77b4; }
    </style>
    """, unsafe_allow_html=True)
    
    # 检查是否需要显示注册表单
    if st.session_state.get("show_register"):
        page_register()
        return
    
    st.title("🎫 券码领取系统")
    
    with st.form("login_form"):
        username = st.text_input("用户名")
        password = st.text_input("密码", type="password")
        submit = st.form_submit_button("登录", use_container_width=True)
        
        if submit:
            user = verify_login(username, password)
            if user:
                # 检查用户是否被禁用
                if user[1] == "disabled":
                    st.error("账号已被禁用，请联系管理员")
                else:
                    st.session_state["logged_in"] = True
                    st.session_state["user_id"] = user[0]
                    st.session_state["username"] = username
                    st.session_state["role"] = user[1]
                    st.session_state["name"] = user[2] or username
                    st.session_state["department"] = user[3] or ""
                    # 生成token并设置URL参数
                    token = generate_session_token(user[0])
                    st.query_params["token"] = token
                    st.rerun()
            else:
                st.error("用户名或密码错误")
    
    st.markdown("---")
    
    # 注册按钮
    if st.button("➕ 注册新账号", use_container_width=True):
        st.session_state["show_register"] = True
        st.rerun()

def page_register():
    """注册页面 - 只需姓名和密码"""
    st.set_page_config(page_title="用户注册", page_icon="➕")
    
    st.title("➕ 用户注册")
    
    with st.form("register_form"):
        name = st.text_input("姓名（作为登录账号）")
        password = st.text_input("密码", type="password")
        confirm_password = st.text_input("确认密码", type="password")
        
        submit = st.form_submit_button("注册", use_container_width=True)
        
        if submit:
            if not name or not password:
                st.error("请填写所有必填项")
            elif password != confirm_password:
                st.error("两次输入的密码不一致")
            elif len(password) < 6:
                st.error("密码长度至少6位")
            else:
                # 直接注册成功，无需审批
                if add_user(name, password, "user", name, ""):
                    st.success("注册成功！现在可以登录")
                    st.session_state["show_register"] = False
                    if st.button("立即登录"):
                        st.rerun()
                else:
                    st.error("姓名已存在，请更换")
    
    if st.button("← 返回登录"):
        st.session_state["show_register"] = False
        st.rerun()

def get_available_amounts():
    """获取所有可用的券码金额"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT DISTINCT amount FROM coupons WHERE status='pending' ORDER BY amount DESC")
    amounts = [row[0] for row in c.fetchall()]
    conn.close()
    return amounts

def get_available_coupons_by_amount(amount):
    """根据金额获取可用的券码数量"""
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM coupons WHERE status='pending' AND amount=?", (amount,))
    count = c.fetchone()[0]
    conn.close()
    return count

def page_user_home():
    st.set_page_config(page_title="券码领取", page_icon="🎫")
    
    st.title(f"🎫 欢迎，{st.session_state.get('name', '')}")
    
    # 显示已审批通过的券码
    conn = get_db()
    c = conn.cursor()
    user_name = st.session_state.get("name", "")
    c.execute("SELECT id, code, amount, issue_time FROM coupons WHERE issued_to=? AND status='issued' ORDER BY id DESC", (user_name,))
    my_coupons = c.fetchall()
    conn.close()
    
    if my_coupons:
        st.subheader("🎉 已领取的券码")
        data = []
        for r in my_coupons:
            data.append({"券码": r[1], "金额": f"¥{r[2]}", "领取时间": r[3] or "-"})
        import pandas as pd
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.divider()
    
    # 显示待审批的申请
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, code, amount, apply_time FROM coupons WHERE issued_to=? AND status='applying' ORDER BY id DESC", (user_name,))
    applying_coupons = c.fetchall()
    conn.close()
    
    if applying_coupons:
        st.subheader("⏳ 待审批的申请")
        data = []
        for r in applying_coupons:
            # 待审批状态不显示券码内容，审批通过后才可见
            data.append({"金额": f"¥{r[2]}", "申请时间": r[3] or "-", "状态": "审核中"})
        import pandas as pd
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.divider()
    
    # 领取新券码
    available_amounts = get_available_amounts()
    
    st.subheader("📥 领取新券码")
    
    if available_amounts:
        col1, col2 = st.columns(2)
        
        with col1:
            selected_amount = st.selectbox(
                "选择券码金额",
                available_amounts,
                format_func=lambda x: f"¥{x}",
                key="amount_select"
            )
        
        with col2:
            max_count = get_available_coupons_by_amount(selected_amount)
            if max_count > 0:
                quantity = st.number_input("领取数量", min_value=1, max_value=max_count, value=1, key="qty_input")
                st.write(f"可选数量: {max_count} 张")
            else:
                quantity = 0
                st.warning("该金额暂无券码")
        
        if quantity > 0:
            if st.button(f"申请领取 {quantity} 张 ¥{selected_amount} 券码", type="primary", use_container_width=True):
                conn = get_db()
                c = conn.cursor()
                c.execute("SELECT id, code FROM coupons WHERE status='pending' AND amount=? LIMIT ?", 
                         (selected_amount, quantity))
                coupons = c.fetchall()
                
                if len(coupons) == quantity:
                    for cid, code in coupons:
                        c.execute("UPDATE coupons SET status='applying', issued_to=?, department='用户领取', apply_time=? WHERE id=?",
                                 (user_name, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), cid))
                    conn.commit()
                    st.success(f"已提交申请，等待管理员审批！")
                    st.rerun()
                else:
                    st.error("券码数量不足")
                conn.close()
    else:
        st.info("暂无可领取的券码，请联系管理员上传")

def page_apply():
    st.set_page_config(page_title="申请领取", page_icon="🎫")
    
    st.title("申请领取券码")
    
    if "apply_coupon_id" in st.session_state:
        coupon_id = st.session_state["apply_coupon_id"]
        
        with st.form("apply_form"):
            name = st.text_input("姓名", value=st.session_state.get("name", ""))
            department = st.text_input("事业部")
            submit = st.form_submit_button("提交申请")
            
            if submit:
                if name and department:
                    apply_coupon(coupon_id, name, department)
                    st.success("申请已提交，等待审批！")
                    del st.session_state["apply_coupon_id"]
                    st.rerun()
                else:
                    st.error("请填写完整信息")
        
        if st.button("取消"):
            del st.session_state["apply_coupon_id"]
            st.rerun()
    else:
        st.warning("请先选择要领取的券码")
        if st.button("返回"):
            st.rerun()

def page_user_records():
    st.set_page_config(page_title="我的券码", page_icon="🎫")
    
    st.title("🎫 我的券码")
    
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, code, amount, status, issue_time FROM coupons WHERE issued_to=? ORDER BY id DESC",
              (st.session_state.get("name", ""),))
    records = c.fetchall()
    conn.close()
    
    if records:
        data = []
        for r in records:
            status_emoji = {"pending": "⏳", "applying": "📝", "issued": "✅", "used": "🎉"}.get(r[3], "❓")
            data.append({"券码": r[1], "金额": f"¥{r[2]}", "状态": f"{status_emoji} {r[3]}", "领取时间": r[4] or "-"})
        
        import pandas as pd
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True)
        
        # 可导出
        if st.button("导出我的券码"):
            csv = df.to_csv(index=False, encoding="utf-8-sig")
            st.download_button("下载CSV", csv, "my_coupons.csv", "text/csv")
    else:
        st.info("暂无领取记录")

def page_approver_home():
    st.set_page_config(page_title="审批管理", page_icon="📋")
    
    st.title("📋 审批管理")
    
    # 待审批列表
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, code, amount, issued_to, department, apply_time FROM coupons WHERE status='applying' ORDER BY apply_time")
    applying = c.fetchall()
    conn.close()
    
    st.subheader(f"待审批 ({len(applying)})")
    if applying:
        for coupon in applying:
            with st.container():
                st.write(f"**券码**: {coupon[1]} | **金额**: ¥{coupon[2]}")
                st.write(f"**申请人**: {coupon[3]} | **事业部**: {coupon[4]} | **申请时间**: {coupon[5]}")
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("✅ 批准", key=f"app_{coupon[0]}"):
                        approve_coupon(coupon[0], "approve")
                        st.rerun()
                with col2:
                    if st.button("❌ 拒绝", key=f"rej_{coupon[0]}"):
                        approve_coupon(coupon[0], "reject")
                        st.rerun()
                st.divider()
    else:
        st.info("暂无待审批的申请")

def page_approver_records():
    st.set_page_config(page_title="审批记录", page_icon="📊")
    
    st.title("📊 审批记录")
    
    stats = get_statistics()
    
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("待领取", stats.get("pending", 0))
    col2.metric("申请中", stats.get("applying", 0))
    col3.metric("已发放", stats.get("issued", 0))
    col4.metric("已使用", stats.get("used", 0))
    
    st.subheader("所有券码")
    all_coupons = get_coupons()
    
    data = []
    for c in all_coupons:
        data.append({"ID": c[0], "券码": c[1], "金额": c[2], "状态": c[3], "领取人": c[4] or "-", "事业部": c[5] or "-", "申请时间": c[6] or "-", "发放时间": c[7] or "-"})
    
    if data:
        import pandas as pd
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True)

def page_admin_home():
    st.set_page_config(page_title="管理后台", page_icon="⚙️")
    
    st.title("⚙️ 券码管理")
    
    # 统计
    stats = get_statistics()
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("待领取", stats.get("pending", 0))
    col2.metric("申请中", stats.get("applying", 0))
    col3.metric("已领取", stats.get("issued", 0))
    col4.metric("总计", sum(stats.values()))
    
    # 待审批列表
    st.subheader("📋 待审批")
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, code, amount, issued_to, department, apply_time FROM coupons WHERE status='applying' ORDER BY id DESC")
    applying = c.fetchall()
    
    if applying:
        # 按申请人分组统计
        applicants = {}
        for r in applying:
            name = r[3]
            if name not in applicants:
                applicants[name] = {"count": 0, "amount": 0, "ids": []}
            applicants[name]["count"] += 1
            applicants[name]["amount"] += r[2]
            applicants[name]["ids"].append(r[0])
        
        # 显示待审批列表
        data = []
        for r in applying:
            data.append({"ID": r[0], "券码": r[1], "金额": r[2], "申请人": r[3], "申请时间": r[5] or "-"})
        import pandas as pd
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True)
        
        # 按用户批次审批
        st.subheader("⚡ 审批操作（按用户批次）")
        
        # 显示每个申请人的汇总
        st.write("**待审批用户：**")
        for name, info in applicants.items():
            st.write(f"• {name}: {info['count']}张券，总计 ¥{info['amount']}")
        
        col1, col2 = st.columns(2)
        with col1:
            approve_user = st.selectbox("选择要批准的用户", list(applicants.keys()), key="approve_user")
            if st.button(f"✅ 批准 {approve_user} 的全部申请", type="primary"):
                ids = applicants[approve_user]["ids"]
                for aid in ids:
                    c.execute("UPDATE coupons SET status='issued', issue_time=? WHERE id=?", 
                             (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), aid))
                conn.commit()
                st.success(f"已批准 {approve_user} 的 {len(ids)} 个申请")
                st.rerun()
        with col2:
            reject_user = st.selectbox("选择要拒绝的用户", list(applicants.keys()), key="reject_user")
            if st.button(f"❌ 拒绝 {reject_user} 的全部申请"):
                ids = applicants[reject_user]["ids"]
                for rid in ids:
                    c.execute("UPDATE coupons SET status='pending', issued_to=NULL, department=NULL, apply_time=NULL WHERE id=?", (rid,))
                conn.commit()
                st.success(f"已拒绝 {reject_user} 的 {len(ids)} 个申请")
                st.rerun()
    else:
        st.info("暂无待审批的申请")
    
    # 上传券码
    st.subheader("📤 上传券码")
    
    st.download_button("下载模板", "券码\n券码2\n券码3", "coupon_template.txt", "text/plain")
    
    with st.form("upload_form"):
        uploaded_file = st.file_uploader("上传券码文件（txt格式，每行一个）", type=["txt"])
        amount = st.number_input("金额（元）", min_value=0.0, value=100.0)
        submit = st.form_submit_button("上传")
        
        if submit and uploaded_file:
            content = uploaded_file.getvalue().decode("utf-8")
            codes = content.strip().split("\n")
            added = upload_coupons(codes, amount)
            st.success(f"成功上传 {added} 个券码")
    
    # 券码列表
    st.subheader("📋 券码列表")
    all_coupons = get_coupons()
    
    data = []
    for c in all_coupons:
        data.append({"ID": c[0], "券码": c[1], "金额": c[2], "状态": c[3], "领取人": c[4] or "-", "事业部": c[5] or "-", "领取时间": c[7] or "-"})
    
    if data:
        import pandas as pd
        df = pd.DataFrame(data)
        st.dataframe(df, use_container_width=True)
        
        # 删除功能
        st.subheader("🗑️ 删除券码")
        
        # 方式一：手动选择ID删除
        st.write("**方式一：手动选择**")
        coupon_ids = [str(c[0]) for c in all_coupons]
        selected = st.multiselect("选择要删除的券码ID", coupon_ids, key="delete_ids")
        if st.button("删除选中", key="delete_selected"):
            if selected:
                deleted = delete_coupons_by_ids([int(cid) for cid in selected])
                st.success(f"成功删除 {deleted} 个券码")
                st.rerun()
        
        st.divider()
        
        # 方式二：上传文件批量删除
        st.write("**方式二：上传文件批量删除**")
        st.info("上传txt文件，每行一个券码或券码ID")
        
        with st.form("batch_delete_form"):
            delete_file = st.file_uploader("上传券码文件", type=["txt"], key="delete_file")
            delete_submit = st.form_submit_button("批量删除")
            
            if delete_submit and delete_file:
                content = delete_file.getvalue().decode("utf-8")
                lines = [line.strip() for line in content.strip().split("\n") if line.strip()]
                
                if lines:
                    # 判断是ID还是券码
                    if lines[0].isdigit():
                        # 按ID删除
                        ids = [int(line) for line in lines if line.isdigit()]
                        deleted = delete_coupons_by_ids(ids)
                        st.success(f"按ID删除成功：{deleted} 个券码")
                    else:
                        # 按券码删除
                        deleted = delete_coupons_by_codes(lines)
                        st.success(f"按券码删除成功：{deleted} 个券码")
                    st.rerun()
    conn.close()

def page_admin_users():
    st.set_page_config(page_title="用户管理", page_icon="👥", layout="wide")
    
    # 科技感样式
    st.markdown("""
    <style>
    .tech-title {
        font-size: 2.5rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 2rem;
        text-shadow: 0 0 30px rgba(102, 126, 234, 0.3);
    }
    .user-card {
        background: linear-gradient(145deg, #1e1e2e 0%, #2d2d44 100%);
        border: 1px solid rgba(102, 126, 234, 0.3);
        border-radius: 12px;
        padding: 1.5rem;
        margin: 1rem 0;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
    }
    .user-card:hover {
        border-color: rgba(102, 126, 234, 0.6);
        box-shadow: 0 6px 25px rgba(102, 126, 234, 0.2);
        transform: translateY(-2px);
    }
    .role-badge {
        display: inline-block;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }
    .role-super_admin { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; }
    .role-approver { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white; }
    .role-user { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white; }
    .stat-card {
        background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid rgba(102, 126, 234, 0.2);
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    }
    .stat-number {
        font-size: 2rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .action-btn {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    .action-btn:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<h1 class="tech-title">👥 用户管理系统</h1>', unsafe_allow_html=True)
    
    # 统计卡片
    users = get_all_users()
    total_users = len(users)
    admin_count = sum(1 for u in users if u[2] == "super_admin")
    approver_count = sum(1 for u in users if u[2] == "approver")
    normal_count = sum(1 for u in users if u[2] == "user")
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(f'<div class="stat-card"><div class="stat-number">{total_users}</div><div>总用户数</div></div>', unsafe_allow_html=True)
    with col2:
        st.markdown(f'<div class="stat-card"><div class="stat-number">{admin_count}</div><div>超级管理员</div></div>', unsafe_allow_html=True)
    with col3:
        st.markdown(f'<div class="stat-card"><div class="stat-number">{approver_count}</div><div>审批员</div></div>', unsafe_allow_html=True)
    with col4:
        st.markdown(f'<div class="stat-card"><div class="stat-number">{normal_count}</div><div>普通用户</div></div>', unsafe_allow_html=True)
    
    st.markdown("---")
    
    # 添加用户区域
    with st.expander("➕ 添加新用户", expanded=False):
        col1, col2, col3 = st.columns(3)
        with col1:
            new_username = st.text_input("用户名", key="new_username")
        with col2:
            new_password = st.text_input("密码", type="password", key="new_password")
        with col3:
            new_role = st.selectbox("角色", ["user", "approver", "super_admin"], key="new_role")
        
        if st.button("添加用户", type="primary", use_container_width=True):
            if not new_username or not new_password:
                st.error("用户名和密码不能为空")
            elif add_user(new_username, new_password, new_role, new_username, ""):
                st.success("✅ 用户添加成功")
                st.rerun()
            else:
                st.error("用户名已存在")
    
    st.markdown("---")
    
    # 用户列表
    st.markdown("### 📋 用户列表")
    
    if users:
        for u in users:
            user_id, username, role, name, dept = u
            
            # 角色样式映射
            role_class = f"role-{role}"
            role_names = {"super_admin": "🔧 超级管理员", "approver": "📋 审批员", "user": "👤 普通用户"}
            
            # 用户卡片
            st.markdown(f"""
            <div class="user-card">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h3 style="margin: 0; color: #e0e0e0;">{username}</h3>
                        <span class="role-badge {role_class}">{role_names.get(role, role)}</span>
                    </div>
                    <div style="color: #888; font-size: 0.9rem;">ID: {user_id}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            
            # 操作按钮（不显示在超级管理员卡片上）
            if role != "super_admin":
                col1, col2, col3 = st.columns([2, 2, 6])
                
                with col1:
                    # 修改角色
                    new_role_select = st.selectbox(
                        "修改角色", 
                        ["user", "approver", "super_admin"],
                        index=["user", "approver", "super_admin"].index(role),
                        key=f"role_{user_id}"
                    )
                    if new_role_select != role:
                        if st.button("确认修改", key=f"update_role_{user_id}"):
                            success, msg = update_user_role(user_id, new_role_select)
                            if success:
                                st.success(f"✅ {msg}")
                                st.rerun()
                            else:
                                st.error(msg)
                
                with col2:
                    # 删除按钮
                    if st.button("🗑️ 删除用户", key=f"delete_{user_id}"):
                        success, msg = delete_user(user_id)
                        if success:
                            st.success(f"✅ {msg}")
                            st.rerun()
                        else:
                            st.error(msg)
                
                st.markdown("<div style='margin-bottom: 1rem;'></div>", unsafe_allow_html=True)
            else:
                st.markdown("<div style='margin-bottom: 1rem; color: #888; font-size: 0.85rem;'>💡 超级管理员不可修改或删除</div>", unsafe_allow_html=True)
    else:
        st.info("暂无用户数据")

def main():
    # 初始化
    init_db()
    
    # 登录检查 - 先检查session，再尝试从URL参数恢复
    if not st.session_state.get("logged_in"):
        # 尝试从URL参数恢复登录状态
        try:
            params = st.query_params
            token = params.get("token")
            if token:
                user = verify_login_by_token(token)
                if user and user[1] != "disabled":
                    # 恢复登录状态，不立即rerun，让页面正常渲染
                    st.session_state["logged_in"] = True
                    st.session_state["user_id"] = user[0]
                    st.session_state["username"] = user[4]
                    st.session_state["role"] = user[1]
                    st.session_state["name"] = user[2] or user[4]
                    st.session_state["department"] = user[3] or ""
                    # 不调用rerun，直接继续执行
                else:
                    page_login()
                    return
            else:
                page_login()
                return
        except Exception as e:
            # 如果URL参数读取失败，显示登录页
            page_login()
            return
    
    # 侧边栏
    role = st.session_state.get("role", "")
    
    st.sidebar.title(f"用户: {st.session_state.get('name', '')}")
    st.sidebar.write(f"角色: {role}")
    
    if role == "super_admin":
        menu = ["首页", "券码管理", "用户管理"]
    elif role == "approver":
        menu = ["首页", "审批管理", "审批记录"]
    elif role == "user":
        menu = ["首页", "我的券码"]
    else:
        menu = ["首页"]
    
    choice = st.sidebar.radio("菜单", menu)
    
    if st.sidebar.button("退出登录"):
        clear_session_token(st.session_state.get("user_id"))  # 清除token
        st.session_state.clear()
        st.query_params.clear()  # 清除URL参数
        st.rerun()
    
    # 页面路由
    if choice == "首页":
        if role == "super_admin":
            page_admin_home()
        elif role == "approver":
            page_approver_home()
        else:
            page_user_home()
    elif choice == "券码管理":
        page_admin_home()
    elif choice == "用户管理":
        page_admin_users()
    elif choice == "我的券码":
        page_user_records()

if __name__ == "__main__":
    main()